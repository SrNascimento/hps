<?php 

define('SERVER', 'localhost');
define('DBNAME', 'hps');
define('USER', 'root');
define('PASSWORD', '');
try {
	
	$conexao = new PDO("mysql:host=" .SERVER."; dbname=" .DBNAME, USER, PASSWORD);
} catch (PDOException $erro) {
	echo 'Mensagem de erro :' . $erro->getMessage() . "<br>";
	echo 'Nome do arquivo : ' . $erro->getfile() . "<br>";
	echo 'Linha : ' . $erro->getline(). "<br>"; 
}


 ?>