						## Projeto HPS – Senai ##

* Hps é uma empresa que fornece serviços terceirizados para clientes físico ou jurídico , sendo os serviços :
      -> Jardineiro , piscineiro , faxineira , diarista , zelador
* Tem contratados , via CLT : 12 funcionários ;
* O contato é feito “ Boca a boca " ; 
* Tem 170 clientes mensais


Principais necessidades {
	
> Sistema de controle de Ponto ( Os funcionários batem o ponto na empresa HPS pra depois seguirem ao trabalho , a após acabar o trabalho retornam a empresa pra bater o ponto [manualmente]);

> Sistema de Controle de Cliente (Cliente armazenados em tabela excel,)
> Sistema de Controle de Estoque (O cliente faz compra dos materiais necessarios para o serviço e não tem controle de gasto nem de preços )
> Pagamento pela Web - Moderninha (Empreendimento aceita cartão , e é um RESULTADO DESEJÁVEL que )
> Emissão de recibos ()
> Agenda ()

}

A ser realizado :

-> Sistema de Clientes {  } ; 
-> Sistema de serviços {  } ;

O sistema de cliente será basicamente um CRUD que poderá cadastrar os clientes e atrelar aos serviços.
o sistema de serviços terá uma área de cadastros de funcionarios , área de atuação 

-----------------------------------------------------------


 -> Dois tipos de cliente ( juridico - fisico ) {
		
		Juridico ( id , razao_social , nome_fantasia, cnpj, endereco, complemento, bairro, cep, numero , contato1, contato2, servico_contratado);

		Fisico (id, nome, sobrenome, cpf, cep, endereco, complemento, bairro,  contato1, contato2, servico_contratado );
	}

	
-> Funcionarios {

	id, nome, sobrenome, cpf, endereco, rua, numero_casa, bairro, contato1, contato2, servico_prestado

}



