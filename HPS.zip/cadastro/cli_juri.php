<?php 
include("conexao/conexao.php");

		$nome = $_POST['nome'];
        $idade = $_POST['idade'];
        $usuario = $_POST['nomeusuario'];

	    $sql_inserir = 'INSERT INTO teste2 (nome,idade,usuario) VALUES (:nome, :idade, :nomeusuario)';

         try {

            $query_inserir = $conexao->prepare($sql_inserir);
            $query_inserir-> bindValue(':nome',$nome,PDO::PARAM_STR);
            $query_inserir-> bindValue(':idade',$idade,PDO::PARAM_STR);
            $query_inserir-> bindValue(':nomeusuario',$usuario,PDO::PARAM_STR);
            $query_inserir->execute();

            //echo "<script> alert('cliente cadastrado com sucesso') </script>";

            header("Location: index.php");
        
        }catch (PDOException $err_cadas) {

            echo'Erro ao cadastrar'.$err_cadas->getMessage;
        
    }

 ?>