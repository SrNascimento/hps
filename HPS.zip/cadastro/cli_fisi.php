<?php 
include("../conexao/conexao.php");


		$nome = $_POST['nome'];
        $sobrenome = $_POST['sobrenome'];
        $cpf = $_POST['cpf'];
        $cep = $_POST['cep'];
        $endereco = $_POST['endereco'];
        $bairro = $_POST['bairro'];
        $contato1 = $_POST['contato1'];
        $contato2 = $_POST['contato2'];

	    $sql_inserir = 'INSERT INTO cli_fisi (nome,sobrenome,cpf,cep,endereco,bairro,contato1,contato2) VALUES (:nome, :sobrenome, :cpf, :cep, :endereco, :bairro, :contato1, :contato2)';

         try {

            $query_inserir = $conexao->prepare($sql_inserir);
            $query_inserir-> bindValue(':nome',$nome,PDO::PARAM_STR);
            $query_inserir-> bindValue(':sobrenome',$sobrenome,PDO::PARAM_STR);
            $query_inserir-> bindValue(':cpf',$cpf,PDO::PARAM_STR);
            $query_inserir-> bindValue(':cep',$cep,PDO::PARAM_STR);
            $query_inserir-> bindValue(':endereco',$endereco,PDO::PARAM_STR);
            $query_inserir-> bindValue(':bairro',$bairro,PDO::PARAM_STR);
            $query_inserir-> bindValue(':contato1',$contato1,PDO::PARAM_STR); 
            $query_inserir-> bindValue(':contato2',$contato2,PDO::PARAM_STR);
            $query_inserir->execute();

           echo "<script> alert('cliente cadastrado com sucesso') </script>";

            header("Location: ../index.php");
        
        }catch (PDOException $err_cadas) {

            echo'Erro ao cadastrar'.$err_cadas->getMessage;
        
    }

 ?>