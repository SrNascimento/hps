<?php 
ob_start();
session_start(); 

if(!isset($_SESSION['usuarioHps']) ){
  header("Location: index.php");
  exit;
}

  include("conexao/conexao.php");

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Painel </title>
	<link rel="stylesheet" href="css/container.css">
	<script src="js/container.js"></script>
</head>
<body>
	<h1> Você esta no painel</h1>

	<!-- QUE LINDO FRONT END -->
	<!-- site que usei https://www.w3schools.com/howto/howto_js_tabs.asp -->
	<form action="login/sair.php" method="post">
		<input type="submit" value="sair" name="sair" onClick="return confirm('Deseja realmente sair do sistema?')">
	</form>
	<br><br><br><br>

	<div class="tab">
  		<button class="tablinks" onclick="abrirAba(event, 'cliente')">Clientes</button>
 		<button class="tablinks" onclick="abrirAba(event, 'funcionario')">Funcionário</button>
  		<button class="tablinks" onclick="abrirAba(event, 'servico')">Serviço</button>
  		<button class="tablinks" onclick="abrirAba(event, 'agenda')">Agenda</button>
	</div>

	<div id="cliente" class="tabcontent">
 		 <h3>Cliente</h3>
 		 <p>Aqui área do cliente</p>
 		 <?php include("descartavel.html"); ?>
	</div>

	<div id="funcionario" class="tabcontent">
		<h3>Funcionário</h3>
  		<p>Área de funcinário</p> 
	</div>

	<div id="servico" class="tabcontent">
 		<h3>Serviço</h3>
  		<p>Área de serviço</p>
	</div>

	<div id="agenda" class="tabcontent">
 		<h3>Agenda</h3>
  		<p>área pra agenda</p>
	</div>


	
</body>
</html>