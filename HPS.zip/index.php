<?php 
ob_start();
session_start(); 

if(isset($_SESSION['usuarioHps']) ){
  header("Location: painel.php");
  exit;
}

  include("conexao/conexao.php");

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>HPS - Login</title>
	<link rel="stylesheet" href="">
</head>
<body>

    <br><br>	
	<form action="login/login.php" method="post" accept-charset="utf-8">
		
		<label>Usuario:</label>
		<input type="text" name="usuario">
		<br><br>

		<label>Senha:</label>
		<input type="password" name="senha">
		<br><br>

		<a href="esqueceu_senha.php">Esqueceu sua senha?</a>
		<br><br>	

		<input type="submit" name="enviar">
	</form>
</body>
</html>

