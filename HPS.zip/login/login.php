<?php 
ob_start();
session_start();

include("../conexao/conexao.php");
									
	if(isset($_POST['enviar'])){
		$usuario = trim(strip_tags($_POST['usuario']));
		$senha	 = trim(strip_tags($_POST['senha']));
		
	$select = "select * from login WHERE BINARY usuario=:usuario AND BINARY senha=:senha ";
		
	try{
		$result = $conexao->prepare($select);
		$result->bindParam(':usuario', $usuario, PDO::PARAM_STR);
		$result->bindParam(':senha', $senha, PDO::PARAM_STR);
		$result->execute();
		$contar = $result->rowCount();
		if($contar>0){
			$usuario = $_POST['usuario'];
			$senha	 = $_POST['senha'];

			$_SESSION['usuarioHps'] = $usuario;
			$_SESSION['senhaHps'] = $senha;
				
			header("Location: ../painel.php");
			} else{
				echo 'dados incorreetos';
			}
			//var_dump($_SESSION['usuarioBrisas'])
			
	}catch(PDOException $erro){
			echo $erro;
	}
		
		
		
	}// se clicar no botão entrar no sistema
	
?>