<?php
include("../conexao/conexao.php");
include("login.php");


if(isset($_POST['sair'])){	
	session_destroy();
	session_unset($_SESSION['usuarioHps']);
	session_unset($_SESSION['senhaHps']);	
	header("Location: ../index.php");	
}
?>